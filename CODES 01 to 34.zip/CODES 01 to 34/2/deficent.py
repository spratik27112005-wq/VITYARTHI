n=int(input("enter a number :"))
def is_deficient(n):
    if n <= 1:
        return False  
    total = 1 
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            total += i
            if i != n // i and n // i != n:
                total += n // i
    return total < n
print (is_deficient(n))  



